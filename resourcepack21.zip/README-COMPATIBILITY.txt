CommieDucks Admin Token + Penny resource pack — Java 1.21.1
===========================================================

This ZIP is specifically for Java 1.21.1 / pack format 34.
- assets/minecraft/models/item/carrot_on_a_stick.json uses legacy CustomModelData overrides.
- CustomModelData 1001 selects the Admin Token.
- CustomModelData 1003 selects Penny.

This pack intentionally does not include the newer 26.2 item-definition format.
The ZIP structure and JSON were validated, but the pack was not launched in-game here.
