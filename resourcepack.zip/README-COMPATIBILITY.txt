CommieDucks Admin Token resource pack
=====================================

This ZIP contains one unified resource pack for Java Edition 1.21.1 and 26.2.

Minecraft 1.21.1:
- Uses the original assets/minecraft/models/item/carrot_on_a_stick.json override.
- Custom Model Data 1001 selects admin_token:item/admin_token.

Minecraft 26.2:
- Uses the overlay at overlays/26_2/.
- The modern item definition reads the first custom_model_data float.
- Value 1001 selects admin_token:item/admin_token; other values fall back to vanilla.

Important:
- This was structurally checked, but not launched in Minecraft in this environment.
- The server must send an item with custom_model_data value 1001. On 26.2, ViaVersion
  must translate that component into the modern custom_model_data float list.
- This pack only addresses the Admin Token item model present in the uploaded ZIP.
