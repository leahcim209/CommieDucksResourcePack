CommieDucks Admin Token + Penny resource pack
==============================================

One ZIP for Minecraft Java 1.21.1 and Eaglercraft 26.2.

Java 1.21.1:
- assets/minecraft/models/item/carrot_on_a_stick.json uses legacy CustomModelData overrides.
- CustomModelData 1001 selects the Admin Token.
- CustomModelData 1003 selects Penny.

Eaglercraft 26.2:
- overlays/26_2/assets/minecraft/items/carrot_on_a_stick.json uses the 26.2 item model definition format.
- It reads the first float in minecraft:custom_model_data.
- 1001 selects the Admin Token; 1003 selects Penny.

The original Admin Token texture is preserved. Penny uses the supplied penny.png.

Compatibility note: the pack structure and JSON were validated, but it was not launched in either client here. Eaglercraft 26.2 must implement Java 26.2 item model definitions and the custom_model_data component for these custom models to render.
