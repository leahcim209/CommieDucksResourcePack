CommieDucks Admin Token + Penny resource pack — Eaglercraft 26.2
================================================================

This ZIP is specifically for the 26.2 item-definition format (pack format 88).
- assets/minecraft/items/carrot_on_a_stick.json uses a range_dispatch on minecraft:custom_model_data.
- It reads float index 0.
- 1001 selects the Admin Token; 1003 selects Penny.

This pack intentionally does not include the legacy 1.21.1 model override file.
The ZIP structure and JSON were validated, but the pack was not launched in-game here.
